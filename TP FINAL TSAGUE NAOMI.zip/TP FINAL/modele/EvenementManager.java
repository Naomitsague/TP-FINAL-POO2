package modele;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EvenementManager {
    private static EvenementManager instance = null;
    private List<Evenement> evenements;

    private static final String FILE_PATH = "evenements.json";

    private EvenementManager() {
        this.evenements = new ArrayList<>();
        chargerEvenementsDepuisFichier();
    }

    public static EvenementManager getInstance() {
        if (instance == null) {
            instance = new EvenementManager();
        }
        return instance;
    }

    public List<Evenement> getEvenements() {
        return evenements;
    }

    private void chargerEvenementsDepuisFichier() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File fichier = new File(FILE_PATH);
            if (fichier.exists()) {
                evenements = mapper.readValue(fichier, new TypeReference<List<Evenement>>() {});
            } else {
                System.out.println("Fichier 'evenements.json' introuvable. Liste d'événements vide.");
                evenements = new ArrayList<>();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erreur lors du chargement des événements.");
        }
    }

    public void sauvegarderEvenements() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(FILE_PATH), evenements);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erreur lors de la sauvegarde des événements.");
        }
    }

    public void ajouterEvenement(Evenement evt) {
        evenements.add(evt);
        sauvegarderEvenements();
    }

    public void supprimerEvenement(Evenement evt) {
        evenements.remove(evt);
        sauvegarderEvenements();
    }
}
