package modele;

import exceptions.CapaciteMaxAtteinteException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public abstract class Evenement {
    protected String id;
    protected String nom;
    protected LocalDateTime dateHeure;
    protected String lieu;
    protected int capaciteMax;
    protected List<Participant> participants;
    protected boolean annule;

    public Evenement() {
        participants = new ArrayList<>();
        annule = false;
    }

    public Evenement(String id, String nom, LocalDateTime dateHeure, String lieu, int capaciteMax) {
        this();
        this.id = id;
        this.nom = nom;
        this.dateHeure = dateHeure;
        this.lieu = lieu;
        this.capaciteMax = capaciteMax;
    }

    public String getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public LocalDateTime getDateHeure() {
        return dateHeure;
    }

    public String getLieu() {
        return lieu;
    }

    public int getCapaciteMax() {
        return capaciteMax;
    }

    public List<Participant> getParticipants() {
        return participants;
    }

    public int getNombreParticipants() {
        return participants.size();
    }

    public boolean isAnnule() {
        return annule;
    }

    public void ajouterParticipant(Participant p) throws CapaciteMaxAtteinteException {
        if (annule) {
            throw new CapaciteMaxAtteinteException("L'événement est annulé.");
        }
        if (participants.size() >= capaciteMax) {
            throw new CapaciteMaxAtteinteException("Capacité maximale atteinte.");
        }
        participants.add(p);
    }

    public void annuler() {
        annule = true;
        // Notifier les participants si besoin
    }

    public abstract String afficherDetails();
}
