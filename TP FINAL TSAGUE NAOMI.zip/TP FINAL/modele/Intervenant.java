package modele;

public class Intervenant {
    private String nom;
    private String expertise;

    public Intervenant(String nom, String expertise) {
        this.nom = nom;
        this.expertise = expertise;
    }

    public String getNom() {
        return nom;
    }

    public String getExpertise() {
        return expertise;
    }

    @Override
    public String toString() {
        return nom + " (" + expertise + ")";
    }
}
