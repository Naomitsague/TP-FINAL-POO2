package modele;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import exceptions.EvenementDejaExistantException;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GestionEvenements {
    private static GestionEvenements instance;
    private Map<String, Evenement> evenements;

    private GestionEvenements() {
        evenements = new HashMap<>();
    }

    public static GestionEvenements getInstance() {
        if (instance == null) {
            instance = new GestionEvenements();
        }
        return instance;
    }

    public Map<String, Evenement> getEvenements() {
        return evenements;
    }

    public void ajouterEvenement(Evenement e) throws EvenementDejaExistantException {
        if (evenements.containsKey(e.getId())) {
            throw new EvenementDejaExistantException("L'événement avec l'id " + e.getId() + " existe déjà.");
        }
        evenements.put(e.getId(), e);
    }

    public Evenement rechercherEvenement(String id) {
        return evenements.get(id);
    }

    public void supprimerEvenement(String id) {
        evenements.remove(id);
    }

    // Sauvegarder dans JSON
    public void sauvegarderJSON(String fichier) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules(); // Pour gérer LocalDateTime
        mapper.writeValue(new File(fichier), evenements);
    }

    // Charger depuis JSON
    public void chargerJSON(String fichier) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        File file = new File(fichier);
        if (file.exists()) {
            evenements = mapper.readValue(file, new TypeReference<Map<String, Evenement>>() {});
        } else {
            evenements = new HashMap<>();
        }
    }
}
