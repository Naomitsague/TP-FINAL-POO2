package modele;

import java.time.LocalDateTime;

public class Concert extends Evenement {
    private String artiste;
    private String typeMusique;

    public Concert(String id, String nom, LocalDateTime dateHeure, String lieu, int capaciteMax, String artiste, String typeMusique) {
        super(id, nom, dateHeure, lieu, capaciteMax);
        this.artiste = artiste;
        this.typeMusique = typeMusique;
    }

    public String getArtiste() {
        return artiste;
    }

    public String getTypeMusique() {
        return typeMusique;
    }

    @Override
    public String afficherDetails() {
        return "Concert '" + nom + "' à " + lieu + " le " + dateHeure + 
               ", artiste: " + artiste + ", style musical: " + typeMusique + 
               ", capacité max: " + capaciteMax + ", participants inscrits: " + getNombreParticipants();
    }
}
