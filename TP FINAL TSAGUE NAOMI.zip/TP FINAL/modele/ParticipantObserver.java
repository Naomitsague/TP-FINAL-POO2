package modele;

public interface ParticipantObserver {
    void recevoirNotification(String message);
}
