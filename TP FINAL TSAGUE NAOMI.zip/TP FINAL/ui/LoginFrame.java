package ui;

import modele.Evenement;
import modele.Organisateur;
import modele.Participant;
import modele.GestionEvenements;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.stream.Collectors;

public class LoginFrame extends JFrame {
    private JTextField loginField;
    private JPasswordField passwordField;
    private JButton btnLogin;
    private JLabel statusLabel;

    public LoginFrame() {
        setTitle("Connexion");
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        panel.add(new JLabel("Login :"));
        loginField = new JTextField();
        panel.add(loginField);

        panel.add(new JLabel("Mot de passe :"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        btnLogin = new JButton("Se connecter");
        panel.add(btnLogin);

        statusLabel = new JLabel();
        panel.add(statusLabel);

        add(panel);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login = loginField.getText();
                String password = new String(passwordField.getPassword());
                authentifier(login, password);
            }
        });
    }

    private void authentifier(String login, String password) {
        if ("org".equals(login) && "org123".equals(password)) {
            OrganisateurFrame orgFrame = new OrganisateurFrame();
            orgFrame.setVisible(true);
            this.dispose();
        } else if ("part".equals(login) && "part123".equals(password)) {
            var evenementsList = GestionEvenements.getInstance()
                .getEvenements()
                .values()
                .stream()
                .collect(Collectors.toList());

            ParticipantFrame partFrame = new ParticipantFrame(evenementsList);
            partFrame.setVisible(true);
            this.dispose();
        } else {
            statusLabel.setText("Login ou mot de passe incorrect");
        }
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
