package ui;

import modele.*;
import exceptions.EvenementDejaExistantException;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.UUID;

public class OrganisateurFrame extends JFrame {
    private JButton btnAjouterConference, btnAjouterConcert, btnRetour;
    private JTextArea logArea;

    public OrganisateurFrame() {
        setTitle("Espace Organisateur");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel btnPanel = new JPanel(new GridLayout(3, 1, 10, 10));

        btnAjouterConference = new JButton("Ajouter Conférence");
        btnAjouterConcert = new JButton("Ajouter Concert");
        btnRetour = new JButton("Retour Connexion");

        btnPanel.add(btnAjouterConference);
        btnPanel.add(btnAjouterConcert);
        btnPanel.add(btnRetour);

        add(btnPanel, BorderLayout.NORTH);

        logArea = new JTextArea();
        logArea.setEditable(false);
        add(new JScrollPane(logArea), BorderLayout.CENTER);

        // Actions boutons
        btnAjouterConference.addActionListener(e -> ajouterConference());
        btnAjouterConcert.addActionListener(e -> ajouterConcert());
        btnRetour.addActionListener(e -> {
            new LoginFrame();
            dispose();
        });

        // Chargement des événements existants
        try {
            GestionEvenements.getInstance().chargerJSON("evenements.json");
            logArea.append("Événements chargés.\n");
        } catch (IOException ex) {
            logArea.append("Erreur lors du chargement JSON : " + ex.getMessage() + "\n");
        }

        setVisible(true);
    }

    private void ajouterConference() {
        String nom = JOptionPane.showInputDialog(this, "Nom Conférence ?");
        if (nom == null || nom.trim().isEmpty()) return;

        String lieu = JOptionPane.showInputDialog(this, "Lieu ?");
        if (lieu == null || lieu.trim().isEmpty()) return;

        String theme = JOptionPane.showInputDialog(this, "Thème ?");
        if (theme == null || theme.trim().isEmpty()) return;

        int capacite = 50; // capacité fixe

        Conference conf = new Conference(
            UUID.randomUUID().toString(),
            nom,
            LocalDateTime.now(),
            lieu,
            capacite,
            theme
        );

        try {
            GestionEvenements.getInstance().ajouterEvenement(conf);
            sauvegarderEtLog("Conférence ajoutée : " + nom);
        } catch (EvenementDejaExistantException ex) {
            logArea.append("Erreur : " + ex.getMessage() + "\n");
        }
    }

    private void ajouterConcert() {
        String nom = JOptionPane.showInputDialog(this, "Nom Concert ?");
        if (nom == null || nom.trim().isEmpty()) return;

        String lieu = JOptionPane.showInputDialog(this, "Lieu ?");
        if (lieu == null || lieu.trim().isEmpty()) return;

        String artiste = JOptionPane.showInputDialog(this, "Artiste ?");
        if (artiste == null || artiste.trim().isEmpty()) return;

        String typeMusique = JOptionPane.showInputDialog(this, "Type Musique ?");
        if (typeMusique == null || typeMusique.trim().isEmpty()) return;

        int capacite = 100;

        Concert concert = new Concert(
            UUID.randomUUID().toString(),
            nom,
            LocalDateTime.now(),
            lieu,
            capacite,
            artiste,
            typeMusique
        );

        try {
            GestionEvenements.getInstance().ajouterEvenement(concert);
            sauvegarderEtLog("Concert ajouté : " + nom);
        } catch (EvenementDejaExistantException ex) {
            logArea.append("Erreur : " + ex.getMessage() + "\n");
        }
    }

    private void sauvegarderEtLog(String msg) {
        try {
            GestionEvenements.getInstance().sauvegarderJSON("evenements.json");
            logArea.append(msg + "\n");
        } catch (IOException ex) {
            logArea.append("Erreur lors de la sauvegarde JSON : " + ex.getMessage() + "\n");
        }
    }
}
