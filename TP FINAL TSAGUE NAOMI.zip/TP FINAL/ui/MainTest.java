package ui;
import modele.Concert;
import modele.Evenement;
import modele.GestionEvenements;

import java.time.LocalDateTime;

public class MainTest {
    public static void main(String[] args) {
        GestionEvenements gestion = GestionEvenements.getInstance();

        try {
            // Création événements
            Evenement concert = new Concert("c1", "Jazz Night", LocalDateTime.now(), "Salle Concert", 100, "Miles Davis", "Jazz");
            gestion.ajouterEvenement(concert);

            // Sauvegarder dans fichier JSON
            gestion.sauvegarderJSON("evenements.json");
            System.out.println("Événements sauvegardés dans evenements.json");

            // Vider la collection pour tester le chargement
            gestion.getEvenements().clear();

            // Charger depuis fichier JSON
            gestion.chargerJSON("evenements.json");
            System.out.println("Nombre d'événements chargés : " + gestion.getEvenements().size());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
