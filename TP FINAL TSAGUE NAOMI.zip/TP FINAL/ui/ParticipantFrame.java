package ui;

import modele.Evenement;
import modele.Participant;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ParticipantFrame extends JFrame {
    private List<Evenement> evenements;

    public ParticipantFrame(List<Evenement> evenements) {
        this.evenements = evenements;
        setTitle("Espace Participant");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JLabel titleLabel = new JLabel("Liste des événements disponibles");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        for (Evenement e : evenements) {
            model.addElement(e.getNom() + " - " + e.getDateHeure());
        }

        JList<String> eventList = new JList<>(model);
        add(new JScrollPane(eventList), BorderLayout.CENTER);
    }
}
