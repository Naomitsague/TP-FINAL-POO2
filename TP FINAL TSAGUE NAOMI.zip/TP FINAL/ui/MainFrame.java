package ui;

import modele.*;
import exceptions.CapaciteMaxAtteinteException;
import exceptions.EvenementDejaExistantException;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.time.LocalDateTime;

public class MainFrame extends JFrame {
    private JTextField participantNom;
    private JTextField participantEmail;
    private JComboBox<String> listeEvenements;
    private JButton btnInscrire;
    private JTextArea logArea;
    private JButton btnAfficherDetails;
    private JButton btnAnnulerEvenement;

    private static final String FICHIER_JSON = "evenements.json";

    public MainFrame() {
        setTitle("Gestion Événements");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Apparence
        Font police = new Font("Segoe UI", Font.PLAIN, 14);
        Color fond = new Color(245, 245, 245);

        // Panel formulaire
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        formPanel.setBackground(fond);

        formPanel.add(new JLabel("Nom participant :"));
        participantNom = new JTextField();
        participantNom.setFont(police);
        formPanel.add(participantNom);

        formPanel.add(new JLabel("Email participant :"));
        participantEmail = new JTextField();
        participantEmail.setFont(police);
        formPanel.add(participantEmail);

        formPanel.add(new JLabel("Choisir événement :"));
        listeEvenements = new JComboBox<>();
        listeEvenements.setFont(police);
        formPanel.add(listeEvenements);

        btnInscrire = new JButton("Inscrire");
        btnInscrire.setFont(police);
        btnInscrire.setBorder(BorderFactory.createEtchedBorder());
        formPanel.add(btnInscrire);

        btnAfficherDetails = new JButton("Afficher détails");
        btnAfficherDetails.setFont(police);
        btnAfficherDetails.setBorder(BorderFactory.createEtchedBorder());
        formPanel.add(btnAfficherDetails);

        btnAnnulerEvenement = new JButton("Annuler événement");
        btnAnnulerEvenement.setFont(police);
        btnAnnulerEvenement.setBorder(BorderFactory.createEtchedBorder());
        formPanel.add(btnAnnulerEvenement);

        add(formPanel, BorderLayout.NORTH);

        // Zone de log
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        logArea.setBackground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Journal d'activités"));
        add(scrollPane, BorderLayout.CENTER);

        // Chargement des événements
        try {
            GestionEvenements.getInstance().chargerJSON(FICHIER_JSON);
            logArea.append("Événements chargés depuis JSON.\n");
        } catch (IOException e) {
            logArea.append("Fichier JSON non trouvé, initialisation manuelle.\n");
            initialiserEvenements();
            try {
                GestionEvenements.getInstance().sauvegarderJSON(FICHIER_JSON);
                logArea.append("Événements sauvegardés dans JSON.\n");
            } catch (IOException ex) {
                logArea.append("Erreur lors de la sauvegarde JSON : " + ex.getMessage() + "\n");
            }
        }

        mettreAJourListeEvenements();

        // Listeners
        btnInscrire.addActionListener(e -> inscrireParticipant());
        btnAfficherDetails.addActionListener(e -> afficherDetailsEvenement());
        btnAnnulerEvenement.addActionListener(e -> annulerEvenement());

        setVisible(true);
    }

    private void initialiserEvenements() {
        GestionEvenements gestion = GestionEvenements.getInstance();
        try {
            Evenement concert1 = new Concert(
                "c1", "Rock Night", LocalDateTime.now().plusDays(5), "Stade", 3, "The Rockers", "Rock");
            Evenement conference1 = new Conference(
                "conf1", "Conf Java", LocalDateTime.now().plusDays(10), "Salle 1", 2, "Programmation Java");

            gestion.ajouterEvenement(concert1);
            gestion.ajouterEvenement(conference1);

            logArea.append("Événements initialisés.\n");
        } catch (EvenementDejaExistantException ex) {
            logArea.append("Erreur lors de l'initialisation : " + ex.getMessage() + "\n");
        }
    }

    private void mettreAJourListeEvenements() {
        listeEvenements.removeAllItems();
        for (String id : GestionEvenements.getInstance().getEvenements().keySet()) {
            listeEvenements.addItem(id);
        }
    }

    private void inscrireParticipant() {
        String nom = participantNom.getText().trim();
        String email = participantEmail.getText().trim();
        String idEvent = (String) listeEvenements.getSelectedItem();

        if (nom.isEmpty() || email.isEmpty() || idEvent == null) {
            logArea.append("Veuillez remplir tous les champs.\n");
            return;
        }

        Participant participant = new Participant("p" + System.currentTimeMillis(), nom, email);
        GestionEvenements gestion = GestionEvenements.getInstance();
        Evenement event = gestion.rechercherEvenement(idEvent);

        if (event == null) {
            logArea.append("Événement introuvable.\n");
            return;
        }

        try {
            event.ajouterParticipant(participant);
            logArea.append(nom + " inscrit à " + event.getNom() + ".\n");
            logArea.append("    Lieu : " + event.getLieu() + "\n");
            logArea.append("    Participants : " + event.getNombreParticipants() + "/" + event.getCapaciteMax() + "\n");

            gestion.sauvegarderJSON(FICHIER_JSON);
        } catch (CapaciteMaxAtteinteException | IOException ex) {
            logArea.append("Erreur : " + ex.getMessage() + "\n");
        }
    }

    private void afficherDetailsEvenement() {
        String idEvent = (String) listeEvenements.getSelectedItem();
        if (idEvent == null) {
            logArea.append("Aucun événement sélectionné.\n");
            return;
        }

        Evenement event = GestionEvenements.getInstance().rechercherEvenement(idEvent);
        if (event != null) {
            logArea.append("Détails :\n");
            logArea.append(event.afficherDetails() + "\n");
        } else {
            logArea.append("Événement introuvable.\n");
        }
    }

    private void annulerEvenement() {
        String idEvent = (String) listeEvenements.getSelectedItem();
        if (idEvent == null) {
            logArea.append("Aucun événement sélectionné.\n");
            return;
        }

        GestionEvenements gestion = GestionEvenements.getInstance();
        Evenement event = gestion.rechercherEvenement(idEvent);

        if (event != null) {
            event.annuler();
            logArea.append("Événement '" + event.getNom() + "' annulé. Notifications envoyées.\n");
            try {
                gestion.sauvegarderJSON(FICHIER_JSON);
            } catch (IOException e) {
                logArea.append("Erreur sauvegarde JSON : " + e.getMessage() + "\n");
            }
        } else {
            logArea.append("Événement introuvable.\n");
        }
    }

    public static void main(String[] args) {
        // Appliquer Nimbus Look & Feel
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Nimbus Look and Feel non disponible.");
        }

        SwingUtilities.invokeLater(MainFrame::new);
    }
}
