package exceptions;


public class CapaciteMaxAtteinteException extends Exception {
    public CapaciteMaxAtteinteException(String message) {
        super(message);
    }
}
